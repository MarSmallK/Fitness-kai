package group27.xukai.cpt202b.Service;

import group27.xukai.cpt202b.Repository.add_trainerRepository;
import group27.xukai.cpt202b.entity.trainer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;

@Service
public class add_trainerService {

    private final add_trainerRepository addTrainerRepository;

    @Autowired
    public add_trainerService(add_trainerRepository addTrainerRepository) {
        this.addTrainerRepository = addTrainerRepository;
    }

    public void addTrainer(String name, String sex, String honour, String experience, LocalDateTime entryTime) {
        // Create a new trainer object
        trainer newTrainer = new trainer(name, sex, honour, experience, entryTime);

        // Save the trainer using the repository
        addTrainerRepository.save(newTrainer);

        // Create a new trainer object
//        trainer newTrainer = new trainer();
//        newTrainer.setName(name);
//        newTrainer.setSex(sex);
//        newTrainer.setHonour(honour);
//        newTrainer.setExperience(experience);
//        newTrainer.setEntryTime(entryTime);


    }
}
