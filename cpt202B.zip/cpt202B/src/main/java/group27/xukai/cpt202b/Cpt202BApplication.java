package group27.xukai.cpt202b;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Cpt202BApplication {

    public static void main(String[] args) {
        SpringApplication.run(Cpt202BApplication.class, args);
    }

}
